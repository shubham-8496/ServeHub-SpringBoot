package com.cdac.servehub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServehubApplicationTests {

	@Test
	void contextLoads() {
	}

}
